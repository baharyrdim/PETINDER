import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Petinder',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.black,
        textTheme: TextTheme(
          bodyText1: TextStyle(color: Colors.white),
          bodyText2: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => MyHomePage(title: 'Petinder'),
        '/login': (context) => LoginPage(title: 'Login'),
        '/signup': (context) => SignUpPage(title: 'Sign Up'),
        '/swipe': (context) => SwipePage(),
        '/settings': (context) => UserSettings(),
        '/update': (context) => UpdateUserInfo(),
        '/addphotopage': (context) => AddPhotoPage(),
      }, //Path
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;

  MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  child: Image.asset(
                    'img/petinder.png',
                    width: 300,
                    height: 300,
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/login');
              },
              child: Text('Login'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/signup');
              },
              child: Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  final String title;

  LoginPage({Key? key, required this.title}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  Future<void> _login() async {
    try {
      UserCredential userCredential;
      if (_emailController.text == 'max@gmail.com' && _passwordController.text == '1234567') {
        userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text,
          password: _passwordController.text,
        );
      } else {
        userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text,
          password: _passwordController.text,
        );
      }
      if (userCredential.user != null) {
        Navigator.pushReplacementNamed(context, '/swipe');
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'wrong-password') {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Error'),
              content: Text('Wrong email or password'),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset(
                'img/login.png',
                width: 200,
                height: 200,
              ),
              SizedBox(height: 8),
              TextFormField(
                controller: _emailController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Enter your email',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _passwordController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Enter your password',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  return null;
                },
                obscureText: true,
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _login();
                  } else {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Error'),
                          content: Text('Please enter valid email and password'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text('OK'),
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
                child: Text('Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AddPhotoPage extends StatefulWidget {
  @override
  _AddPhotoPageState createState() => _AddPhotoPageState();
}

class _AddPhotoPageState extends State<AddPhotoPage> {
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;

  Future<void> _getImage() async {
    final XFile? selectedImage = await _picker.pickImage(source: ImageSource.gallery);

    if (selectedImage != null) {
      setState(() {
        _imageFile = selectedImage;
      });
    }
  }

  Future<void> _uploadImage() async {
    if (_imageFile != null) {
      Reference firebaseStorageRef = FirebaseStorage.instance.ref().child('user_images/${DateTime.now()}.jpg');

      try {
        await firebaseStorageRef.putFile(File(_imageFile!.path));
        final String downloadURL = await firebaseStorageRef.getDownloadURL();
        await FirebaseFirestore.instance.collection('user_photos').add({
          'url': downloadURL,
          'timestamp': FieldValue.serverTimestamp(),
        });

        Navigator.pushReplacementNamed(context, '/login');
      } catch (e) {
        print('Error uploading image: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Photo'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'ADD PHOTO',
              style: TextStyle(
                fontSize: 45.0,
                color: Color(0xFFDAFF60),
                fontWeight: FontWeight.bold,
                fontFamily: 'Inter',
                letterSpacing: 2.0,
                shadows: [
                  Shadow(
                    blurRadius: 8.0,
                    color: Color(0xFFDAFF60),
                    offset: Offset(0, 0),
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: _getImage,
              child: Text('Select Profile Photo'),
            ),
            if (_imageFile != null)
              Image.file(
                File(_imageFile!.path),
                width: 150,
                height: 150,
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _uploadImage,
              child: Text('Upload Photo'),
            ),
            SizedBox(height: 20),
            TextButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/login');
              },
              child: Text('Maybe Later'),
            ),
          ],
        ),
      ),
    );
  }
}

class SignUpPage extends StatefulWidget {
  final String title;

  SignUpPage({Key? key, required this.title}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _ageController = TextEditingController();
  TextEditingController _cityController = TextEditingController();
  String? _selectedPetType;
  bool _isChecked = false;
  bool _isButtonEnabled() {
    return _isChecked;
  }

  Future<void> _signUp() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );

      if (userCredential.user != null) {
        await FirebaseFirestore.instance.collection('users').doc(userCredential.user!.uid).set({
          'name': _nameController.text,
          'age': _ageController.text,
          'city': _cityController.text,
          'petType': _selectedPetType ?? '',
        });

        Navigator.pushNamed(context, '/addphotopage');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'img/signup.png',
                  width: 200,
                  height: 200,
                ),
                TextFormField(
                  controller: _nameController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Name',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your name';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _ageController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Age',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your age';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  style: TextStyle(color: Colors.white),
                  value: _selectedPetType,
                  hint: Text(
                    'Select Type of Pet',
                    style: TextStyle(color: Colors.white70),
                  ),
                  onChanged: (newValue) {
                    setState(() {
                      _selectedPetType = newValue;
                    });
                  },
                  items: <String>['Dog', 'Cat', 'Bird', 'Hamster']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: TextStyle(color: Colors.purpleAccent),
                      ),
                    );
                  }).toList(),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select the type of your pet';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _cityController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'City',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your city';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _emailController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Email',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _passwordController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Password',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password';
                    }
                    return null;
                  },
                  obscureText: true,
                  onChanged: (value) {
                    _passwordController.text = value;
                  },
                ),
                TextFormField(
                  decoration: InputDecoration(
                    hintText: 'Confirm Password',
                    hintStyle: TextStyle(color: Colors.white70),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please confirm your password';
                    }
                    if (value != _passwordController.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                  obscureText: true,
                ),
                Image.asset(
                  'img/terms_conditions.png',
                  width: 250,
                  height: 600,
                ),
                Image.asset(
                  'img/terms_conditions1.png',
                  width: 300,
                  height: 300,
                ),
                Image.asset(
                  'img/terms_conditions2.png',
                  width: 300,
                  height: 300,
                ),
                SizedBox(height: 16),
                CheckboxListTile(
                  title: Text(
                    'I agree to the terms and conditions.',
                    style: TextStyle(color: Colors.white),
                  ),
                  value: _isChecked,
                  onChanged: (bool? value) {
                    setState(() {
                      _isChecked = value!;
                    });
                  },
                  controlAffinity: ListTileControlAffinity.leading,
                  checkColor: Colors.greenAccent,
                  activeColor: Colors.white,
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _isChecked ? () {
                    if (_formKey.currentState!.validate()) {
                      _signUp();
                    }
                  } : null, // Disable button if checkbox is not checked
                  child: Text('Sign Up'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SwipePage extends StatefulWidget {
  @override
  _SwipePageState createState() => _SwipePageState();
}

class _SwipePageState extends State<SwipePage> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    SwipeContent(),
    Favorites(),
    ChatBox(),
    UserSettings(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Page'),
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.purple,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorites',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class SwipeContent extends StatefulWidget {
  @override
  _SwipeContentState createState() => _SwipeContentState();
}

class _SwipeContentState extends State<SwipeContent> {
  String? selectedPetType;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'PETINDER',
          style: TextStyle(
            fontSize: 45.0,
            color: Color(0xFFDAFF60),
            fontWeight: FontWeight.bold,
            fontFamily: 'Inter',
            letterSpacing: 2.0,
            shadows: [
              Shadow(
                blurRadius: 8.0,
                color: Color(0xFFDAFF60),
                offset: Offset(0, 0),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Colors.white,
              labelText: 'Pet Filter',
            ),
            value: selectedPetType,
            onChanged: (newValue) {
              setState(() {
                selectedPetType = newValue;
              });
            },
            items: [
              DropdownMenuItem(
                child: Text('Only Dogs'),
                value: 'Dog',
              ),
              DropdownMenuItem(
                child: Text('Only Cats'),
                value: 'Cat',
              ),
              DropdownMenuItem(
                child: Text('Only Birds'),
                value: 'Bird',
              ),
              DropdownMenuItem(
                child: Text('Only Hamsters'),
                value: 'Hamster',
              ),
              DropdownMenuItem(
                child: Text('All Pets'),
                value: '',
              ),
            ],
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: selectedPetType == null || selectedPetType!.isEmpty
                ? FirebaseFirestore.instance.collection('users').snapshots()
                : FirebaseFirestore.instance
                .collection('users')
                .where('petType', isEqualTo: selectedPetType)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                  child: Text('Something went wrong'),
                );
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }

              final userCards = snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                return {
                  'userId': document.id,
                  'name': data['name'],
                  'age': data['age'],
                  'city': data['city'],
                  'petType': data['petType'],
                  'photoUrl': data['photoUrl'],
                };
              }).toList();
              bool isLiked = false;

              return ListView.builder(
                itemCount: userCards.length,
                itemBuilder: (context, index) {
                  final user = userCards[index];
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16.0),
                          child: user['photoUrl'] != null
                              ? Image.network(
                            user['photoUrl'],
                            height: 300,
                            fit: BoxFit.cover,
                          )
                              : Container(
                            height: 300,
                            color: Colors.grey[300],
                            child: Center(
                              child: Icon(
                                Icons.person,
                                size: 100,
                                color: Colors.grey[600],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16.0),
                        Text(
                          user['name']!,
                          style: TextStyle(
                            fontSize: 24.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8.0),
                        Text(
                          'Age: ${user['age']}, City: ${user['city']}, Pet: ${user['petType']}',
                          style: TextStyle(fontSize: 16.0),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            ElevatedButton.icon(
                              onPressed: () {
                                setState(() {
                                  isLiked = !isLiked;
                                });
                              },
                              icon: Icon(
                                isLiked ? Icons.favorite : Icons.favorite_border,
                                color: isLiked ? Colors.red : null,
                              ),
                              label: Text('Like'),
                            ),

                            ElevatedButton.icon(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MessageScreen(userName: user['name']!),
                                  ),
                                );
                              },
                              icon: Icon(Icons.message),
                              label: Text('Message'),
                            ),

                          ],
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class MessageScreen extends StatefulWidget {
  final String userName;

  MessageScreen({required this.userName});

  @override
  _MessageScreenState createState() => _MessageScreenState();
}

class _MessageScreenState extends State<MessageScreen> {
  List<String> messages = [];

  TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat with ${widget.userName}'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    sendMessage();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void sendMessage() {
    if (messageController.text.isNotEmpty) {
      setState(() {
        messages.add(messageController.text);
        messageController.clear();
      });
      final chatBoxKey = ChatBox.globalKey;
      if (chatBoxKey.currentState != null) {
        chatBoxKey.currentState!.addMessage(widget.userName, messages.last);
      }
    }
  }
}

class Favorites extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _getRandomUsers(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Text('Error: ${snapshot.error}'),
          );
        }

        final List<Map<String, dynamic>> randomUsers = snapshot.data ?? [];

        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              'FAVORITES',
              style: TextStyle(
                fontSize: 45.0,
                color: Color(0xFFDAFF60),
                fontWeight: FontWeight.bold,
                fontFamily: 'Inter',
                letterSpacing: 2.0,
                shadows: [
                  Shadow(
                    blurRadius: 8.0,
                    color: Color(0xFFDAFF60),
                    offset: Offset(0, 0),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: randomUsers
                  .map((user) => _buildShortUserCard(user))
                  .toList(),
            ),
          ],
        );
      },
    );
  }

  Widget _buildShortUserCard(Map<String, dynamic> user) {
    return Container(
      width: 120.0,
      padding: EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 30.0,
            backgroundImage: NetworkImage(user['photoUrl'] ?? ''),
          ),
          SizedBox(height: 8.0),
          Text(
            user['name'] ?? '',
            style: TextStyle(
              fontSize: 14.0,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 4.0),
          Text(
            'Age: ${user['age'] ?? ''}',
            style: TextStyle(fontSize: 12.0),
          ),
          SizedBox(height: 4.0),
          Text(
            'City: ${user['city'] ?? ''}',
            style: TextStyle(fontSize: 12.0),
          ),
          SizedBox(height: 4.0),
          Text(
            'Pet Type: ${user['petType'] ?? ''}',
            style: TextStyle(fontSize: 12.0),
          ),
        ],
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _getRandomUsers() async {
    final List<Map<String, dynamic>> randomUsers = [];

    final QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .orderBy('name')
        .limit(3)
        .get();

    for (QueryDocumentSnapshot documentSnapshot in querySnapshot.docs) {
      final data = documentSnapshot.data() as Map<String, dynamic>;
      randomUsers.add({
        'name': data['name'],
        'age': data['age'],
        'city': data['city'],
        'petType': data['petType'],
        'photoUrl': data['photoUrl'],
      });
    }

    return randomUsers;
  }
}

class ChatBox extends StatefulWidget {
  static final GlobalKey<_ChatBoxState> globalKey = GlobalKey<_ChatBoxState>();
  @override
  _ChatBoxState createState() => _ChatBoxState();
}

class _ChatBoxState extends State<ChatBox> {
  List<Map<String, dynamic>> chatHistory = [];
  void addMessage(String userName, String message) {
    setState(() {
      chatHistory.add({'userName': userName, 'message': message});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat Box'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            'CHAT BOX',
            style: TextStyle(
              fontSize: 45.0,
              color: Color(0xFFDAFF60),
              fontWeight: FontWeight.bold,
              fontFamily: 'Inter',
              letterSpacing: 2.0,
              shadows: [
                Shadow(
                  blurRadius: 8.0,
                  color: Color(0xFFDAFF60),
                  offset: Offset(0, 0),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Center(
            child: Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(15),
              ),
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ConversationScreen()),
                  );
                },
                child: Icon(
                  Icons.message,
                  size: 50,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: chatHistory.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('Chat with ${chatHistory[index]['userName']}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MessageScreen(userName: chatHistory[index]['userName']),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ConversationScreen extends StatefulWidget {
  @override
  _ConversationScreenState createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<ConversationScreen> {
  List<Map<String, dynamic>> chatHistory = [];

  void sendMessage() {

    launch('sms:00905076521701');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat'),
      ),
      body: Column(
        children: [
          Expanded(
            child: chatHistory.isEmpty
                ? Center(child: Text('Do you have any question? Write to us!'))
                : ListView.builder(
              itemCount: chatHistory.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(chatHistory[index]['message']),
                  subtitle: Text(chatHistory[index]['sender']),
                );
              },
            ),
          ),
          Divider(),
          ListTile(
            title: TextField(
              onSubmitted: (value) {
                setState(() {
                  chatHistory.add({'message': value, 'sender': 'user'});
                  sendMessage();
                });
              },
            ),
            trailing: IconButton(
              icon: Icon(Icons.send),
              onPressed: () {
                setState(() {
                  chatHistory.add({'message': 'Sent!', 'sender': 'user'});
                  sendMessage();
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}

class UserSettings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ProfilePage();
  }
}

class ProfilePage extends StatelessWidget {

  final User? user = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UpdateUserInfo()),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(user!.uid).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Something went wrong'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          var userData = snapshot.data!.data() as Map<String, dynamic>;

          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [ Text(
                'PROFILE',
                style: TextStyle(
                  fontSize: 45.0,
                  color: Color(0xFFDAFF60),
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Inter', // Inter font tipi
                  letterSpacing: 2.0,
                  shadows: [
                    Shadow(
                      blurRadius: 8.0,
                      color: Color(0xFFDAFF60),
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
              ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(16.0),
                  child: userData['photoUrl'] != null
                      ? Image.network(
                    userData['photoUrl'],
                    height: 300,
                    fit: BoxFit.cover,
                  )
                      : Container(
                    height: 300,
                    color: Colors.grey[300],
                    child: Center(
                      child: Icon(
                        Icons.person,
                        size: 100,
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Text('Name: ${userData['name']}'),
                Text('Age: ${userData['age']}'),
                Text('City: ${userData['city']}'),
                Text('Pet Type: ${userData['petType']}'),
              ],
            ),
          );
        },
      ),
    );
  }
}

class UpdateUserInfo extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Update User Information'),
      ),
      body: UpdateForm(),
    );
  }
}

class UpdateForm extends StatefulWidget {
  @override
  _UpdateFormState createState() => _UpdateFormState();
}

class _UpdateFormState extends State<UpdateForm> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _ageController = TextEditingController();
  TextEditingController _cityController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  late String _currentPhotoUrl;
  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }
  Future<void> _fetchUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    setState(() {
      _nameController.text = user?.displayName ?? '';
      _emailController.text = user?.email ?? '';
    });
    final userDataSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(user?.uid)
        .get();
    final userData = userDataSnapshot.data() as Map<String, dynamic>;
    setState(() {
      _currentPhotoUrl = userData['photoUrl'];
      _ageController.text = userData['age'];
      _cityController.text = userData['city'];
      _nameController.text = userData['name'];
      _passwordController.text = userData['password'];
    });
  }

  Future<void> _updateUserData() async {
    final user = FirebaseAuth.instance.currentUser;

    if (_emailController.text.isNotEmpty || _passwordController.text.isNotEmpty) {
      try {
        await user?.updateEmail(_emailController.text);
        await user?.updatePassword(_passwordController.text);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error updating email/password: $e'),
          ),
        );
        return;
      }
    }
    try {
      await user?.updateDisplayName(_nameController.text);
      await FirebaseFirestore.instance.collection('users').doc(user?.uid).update({
        'name': _nameController.text,
        'age': _ageController.text,
        'city': _cityController.text,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Your information has been updated.'),
        ),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error updating user data: $e'),
        ),
      );
    }
  }

  Future<void> _addPhoto() async {

    final user = FirebaseAuth.instance.currentUser;

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final storage = firebase_storage.FirebaseStorage.instance;
      final storageRef = storage.ref().child('profile_photos/${user?.uid}');
      await storageRef.putFile(new File(pickedFile.path));

      final downloadURL = await storageRef.getDownloadURL();

      await FirebaseFirestore.instance.collection('users').doc(user?.uid).update({
        'photoUrl': downloadURL,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Your profile photo has been updated.'),
        ),
      );

      setState(() {
        _currentPhotoUrl = downloadURL;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('No photo selected.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Update User Information'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'UPDATE USER INFORMATION',
                style: TextStyle(
                  fontSize: 45.0,
                  color: Color(0xFFDAFF60),
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Inter',
                  letterSpacing: 2.0,
                  shadows: [
                    Shadow(
                      blurRadius: 8.0,
                      color: Color(0xFFDAFF60),
                      offset: Offset(0, 0),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () async {
                  await _addPhoto();
                },
                child: CircleAvatar(
                  radius: 50,
                  child: Icon(
                    Icons.person,
                  ),
                ),
              ),
              TextFormField(
                controller: _nameController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Name',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _ageController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Age',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your age';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _cityController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'City',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your city';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _emailController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'New Email',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
              ),
              TextFormField(
                controller: _passwordController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'New Password',
                  hintStyle: TextStyle(color: Colors.white70),
                ),
                obscureText: true,
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    await _updateUserData();
                  }
                },
                child: Text('Update'),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  await _addPhoto();
                },
                child: Text('Add Photo'),
              ),
              SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}