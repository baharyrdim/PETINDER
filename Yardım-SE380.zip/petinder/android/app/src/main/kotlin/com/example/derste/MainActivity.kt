package com.example.derste

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
